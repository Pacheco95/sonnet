import os, subprocess
from pathlib import Path
root=Path('/tmp/sonnet-373')
base=os.environ.copy()
for key in ('SDL_VULKAN_LIBRARY','VK_DRIVER_FILES','VK_LAYER_PATH','VK_ADD_LAYER_PATH','DYLD_LIBRARY_PATH'):
 base.pop(key,None)
sdk='/tmp/sonnet-368/sdk/macOS'
for driver in ('kosmic','molten'):
 env=base.copy()
 if driver=='kosmic': env.update(SDL_VULKAN_LIBRARY=sdk+'/lib/libvulkan.1.dylib',VK_DRIVER_FILES=sdk+'/share/vulkan/icd.d/libkosmickrisp_icd.json',VK_ADD_LAYER_PATH=sdk+'/share/vulkan/explicit_layer.d')
 for source,path in (('source','/tmp/sonnet-368/basic'),('cooked','/tmp/sonnet-368/cooked/game.sbundle')):
  for term in ('final','albedo'):
   name=f'{driver}-{source}-{term}'
   cmd=['build/macos-debug-local/apps/player/sonnet_player',path,'--scene','scenes/glass.scene.json','--settle-frames','24','--shading-term',term,'--screenshot',str(root/(name+'.png'))]
   with (root/(name+'.log')).open('w') as log: result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
   print(name,result.returncode,flush=True)
   if result.returncode: raise SystemExit(result.returncode)
